# Blockchain-Data
Extracting Blockchain and respective cryptocurrency dataset

Tool used to extract data for a particular blockchain & cryptocurrency  for a specific date or a data range. 
The data can be downloaded as a csv file for easier manipulation. 

The data can be used to understand trends. 
